package android.content;

public class Context {
    Resources none;
    public Resources getResources(){
        return none;
    }
    public String getPackageName(){
        return "virtual_robot";
    }
}
