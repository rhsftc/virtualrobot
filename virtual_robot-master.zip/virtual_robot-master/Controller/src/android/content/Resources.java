package android.content;

public class Resources {
    public int getIdentifier(String name, String defType, String defPackage) {
        return 0;
    }
}