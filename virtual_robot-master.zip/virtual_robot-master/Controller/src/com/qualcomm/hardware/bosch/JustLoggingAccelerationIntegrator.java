package com.qualcomm.hardware.bosch;

import com.qualcomm.hardware.bosch.BNO055IMU;

/**
 * Do-nothing class provided for compatibility with FTC SDK
 */
public class JustLoggingAccelerationIntegrator implements BNO055IMU.AccelerationIntegrator {
}
