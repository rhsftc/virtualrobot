package org.firstinspires.ftc.robotcore.external.hardware.camera;

public class WebcamName {
}
