package org.firstinspires.ftc.robotcore.external.stream;

public class CameraStreamSource {
}
